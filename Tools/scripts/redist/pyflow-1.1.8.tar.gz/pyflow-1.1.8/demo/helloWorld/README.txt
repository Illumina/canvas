The following demo shows a very simple pyFlow composed of only a
single task -- a command which echos a simple message.  You can run
this workflow by typing "python ./helloWorld.py"
