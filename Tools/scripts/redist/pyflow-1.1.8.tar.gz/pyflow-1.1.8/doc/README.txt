client_api/ -> contains documetation on the pyflow API which you can use to create your own workflow scripts

developer/ -> contains documenation that's only useful if you'd like to change or add features to pyflow itself

